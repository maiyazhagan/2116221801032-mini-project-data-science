from flask import Flask, render_template, request, redirect, url_for, send_file
import sqlite3
import os
import io
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

app = Flask(__name__)

DATABASE = 'hotel.db'

def init_db():
    if not os.path.exists(DATABASE):
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY,
                name TEXT,
                email TEXT,
                phone TEXT,
                room_type TEXT,
                checkin_date TEXT,
                checkout_date TEXT,
                taxi_service INTEGER,
                total_amount REAL
            )''')
            cursor.execute('''CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY,
                date TEXT,
                water_usage REAL,
                electricity REAL,
                groceries REAL,
                employee_salaries REAL,
                other_expenses REAL
            )''')
            conn.commit()

init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/book', methods=['POST'])
def book():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    room_type = request.form['room_type']
    checkin_date = request.form['checkin_date']
    checkout_date = request.form['checkout_date']
    taxi_service = request.form.get('taxi_service') == 'on'
    
    room_prices = {'Single Room': 2000, 'Double Room': 3000, 'Four-room Suite': 4500}
    total_amount = room_prices.get(room_type, 0) + (500 if taxi_service else 0)

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO bookings (name, email, phone, room_type, checkin_date, checkout_date, taxi_service, total_amount)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', (name, email, phone, room_type, checkin_date, checkout_date, taxi_service, total_amount))
        booking_id = cursor.lastrowid  # Get the ID of the last inserted row
        conn.commit()
    
    return render_template('index.html', success=True, total_amount=total_amount, booking_id=booking_id)

@app.route('/download_invoice/<int:booking_id>')
def download_invoice(booking_id):
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM bookings WHERE id = ?', (booking_id,))
        booking = cursor.fetchone()
    
    if booking:
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=letter)
        c.drawString(100, 750, f"Invoice for {booking[1]}")  # Name
        c.drawString(100, 730, f"Email: {booking[2]}")
        c.drawString(100, 710, f"Phone: {booking[3]}")
        c.drawString(100, 690, f"Room Type: {booking[4]}")
        c.drawString(100, 670, f"Check-in: {booking[5]}")
        c.drawString(100, 650, f"Check-out: {booking[6]}")
        c.drawString(100, 630, f"Taxi Service: {'Yes' if booking[7] else 'No'}")
        c.drawString(100, 610, f"Total Amount: Rs. {booking[8]}")
        c.showPage()
        c.save()
        buffer.seek(0)
        return send_file(buffer, as_attachment=True, download_name=f"invoice_{booking_id}.pdf", mimetype='application/pdf')

@app.route('/expenses', methods=['POST'])
def expenses():
    date = request.form['date']
    water_usage = float(request.form['water_usage'])
    electricity = float(request.form['electricity'])
    groceries = float(request.form['groceries'])
    employee_salaries = float(request.form['employee_salaries'])
    other_expenses = float(request.form['other_expenses'])

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO expenses (date, water_usage, electricity, groceries, employee_salaries, other_expenses)
                          VALUES (?, ?, ?, ?, ?, ?)''', (date, water_usage, electricity, groceries, employee_salaries, other_expenses))
        conn.commit()
    
    return redirect(url_for('expenses_page'))

@app.route('/expenses_page')
def expenses_page():
    return render_template('expenses.html')

@app.route('/profit', methods=['GET'])
def profit():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT SUM(total_amount) FROM bookings")
        total_revenue = cursor.fetchone()[0] or 0

        cursor.execute("SELECT SUM(water_usage + electricity + groceries + employee_salaries + other_expenses) FROM expenses")
        total_expenses = cursor.fetchone()[0] or 0

        profit = total_revenue - total_expenses
        share = profit / 3
        profit_shares = {'owner_1': share, 'owner_2': share, 'owner_3': share}

    return render_template('profit.html', total_revenue=total_revenue, total_expenses=total_expenses, profit_shares=profit_shares)

@app.route('/predict', methods=['GET'])
def predict():
    return render_template('predict.html')

if __name__ == '__main__':
    app.run(debug=True)
